package com.viceri.test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ViceriApplicationTests {

	@Test
	void contextLoads() {
	}

}
