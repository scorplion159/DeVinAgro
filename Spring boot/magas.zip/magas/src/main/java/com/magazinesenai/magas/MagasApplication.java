package com.magazinesenai.magas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MagasApplication {

	public static void main(String[] args) {
		SpringApplication.run(MagasApplication.class, args);
	}

}
