package com.magazinesenai.magas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MagasApplicationTests {

	@Test
	void contextLoads() {
	}

}
