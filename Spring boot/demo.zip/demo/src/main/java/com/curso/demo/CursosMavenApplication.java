package com.curso.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CursosMavenApplication {

	public static void main(String[] args) {
		SpringApplication.run(CursosMavenApplication.class, args);
	}

}
