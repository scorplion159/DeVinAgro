package com.viceri.viceri.viceri;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ViceriApplication {

	public static void main(String[] args) {
		SpringApplication.run(ViceriApplication.class, args);
	}

}
